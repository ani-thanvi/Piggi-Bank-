<html>
<head>
    <title>Basic Banking System</title>
    <link rel="stylesheet" href="button.css">
	<style>
	button{
		background-color:#8cbed6;
		  border: none;
  color: black;
  padding: 30px 50px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 30px;
  margin: 4px 2px;
  cursor: pointer;
  font-family: "Lucida Console", Courier, monospace;
		border-radius: 12px;
	}
	tr{
		text-align:center;
	}
	body
	{
		text-align:center;
	}
		body{
		background-image:url("bank.jpg");
		background-position: center;
		background-repeat: no-repeat;
		background-size: cover;
	}
	</style>
	<style>
.button {
  border: none;
  color: white;
  padding: 30px 50px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 30px;
  margin: 4px 2px;
  cursor: pointer;
}

.button1 {background-color: #fff;} 
.button2 {background-color: #fff;} 
</style>
</head>
<body >
<h1 class="alert alert-success rounded-0"><small class="float-right text-muted" style="font-size: 20pt;"><kbd>CREATED BY : RISHAV SHARMA</kbd></small></h1>
<br>
	<div id="header">
       <br>
	   <br>
	   <br>
	   <br>
	   <br>
       <h2 style=" font-family:Agency FB; font-size: 55px;color:#FFF;text-shadow: 2px 2px black;"> SPARKS FOUNDATION BANKING SYSTEM </h2>
    </div>
        <div id="section">
            <table>
                <tr></tr>
                <tr><br>
				<a href="getdetail.php">
               <button class="button1" type="button" href="getdetail.php">USER DETAILS</button>
                </a>
                </tr>
				
			   <tr>        
               <br> <br> <br>
			   <a href="transaction.php">
			   <button class="button2" type="button">TRANSACTION INFO</button>
               </a>
               
               </tr>
            </table>
    </div>
</body>
</html>